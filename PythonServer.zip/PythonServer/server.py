from flask import Flask, request

app = Flask(__name__)

@app.route("/")
def home():
	# return render_template('home.html')
	return 'Hello Good sir'

currentmotion = 'S'

@app.route("/postcommands")
def command():
	# motion = request.args.get('command')
	data = request.get_json()
	motion = data['command']
	return 'The command is {}'.format(motion)
	# if motion != lastmotion:
	# 	lastmotion = motion
	# 	if motion == 'S':
	# 			print 'stop'
	# 			motors.stop()
	# 	elif motion == 'R':
	# 			print 'right'
	# 			motors.curveRight(80)
	# 	elif motion == 'L':
	# 			print 'left'
	# 			motors.curveLeft(80)
	# 	elif motion == 'F':
	# 			print 'forward'
	# 			motors.forward()
	# 	elif motion == 'B':
	# 			print 'reverse'
	# 			motors.reverse()

if __name__ == "__main__":
	app.run(debug=True)

